#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
	int sz;
	cout<<"Enter the size of array"<<endl;
	cin>>sz;
	int * list = new int[sz];
	for (int i=0;i<sz;i++)
	{
		cin>>*(list+i);
	}
	int temp;
	for (int i=sz-1;i>0;i--)
	{
		temp=list[i];
		list[i]=list[i-1];
		list[i-1]=temp;
	}
	
	cout<<"The shifted array is :"<<endl;	
	for (int i=0;i<sz;i++)
	{
		cout<<*(list+i)<<endl;
	}
	delete [] list;
	return 0;
}
