#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
	int sz;
	cout<<"Enter the size of array"<<endl;
	cin>>sz;
	int * list = new int[sz];
	for (int i=0;i<sz;i++)
	{
		cin>>*(list+i);
	}
	
	int sm, s_sm;
	int lrg, s_lrg;
	if(list[0]>list[1]){
	  sm = list[0];
	  s_sm = list[1];
	  lrg = list[1];
	  s_lrg = list[0];
	}
	else {
	  sm = list[1];
	  s_sm = list[0];
	  lrg = list[0];
	  s_lrg = list[1];
	}
	
	for(int i=0; i<sz; i++) {
      if(sm>list[i]) { 
         s_sm = sm;
         sm = list[i];
      }
      else if(list[i] < s_sm){
         s_sm = list[i];
      }
   }
   
	for(int i=0; i<sz; i++) {
      if(lrg<list[i]) { 
         s_lrg = lrg;
         lrg = list[i];
      }
      else if(list[i] > s_lrg){
         s_lrg = list[i];
      }
   }
   cout<<s_sm<<endl;
   cout<<s_lrg<<endl;
	return 0;
}
