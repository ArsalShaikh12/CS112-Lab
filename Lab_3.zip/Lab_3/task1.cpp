#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
	int sz;
	cout<<"Enter the size of array"<<endl;
	cin>>sz;
	int * list = new int[sz];
	for (int i=0;i<sz;i++)
	{
		cin>>*(list+i);
	}
	int * diff = new int[sz-1];
	for (int i=0;i<sz-1;i++)
	{
		// cout<<list[i]<<list[i+1]<<endl;
		*(diff+i)=list[i+1]-list[i];
	}
	
	delete [] list;
	for (int i=0;i<sz-1;i++)
	{
		cout<<*(diff+i)<<endl;
	}
	delete [] diff;
	return 0;
}