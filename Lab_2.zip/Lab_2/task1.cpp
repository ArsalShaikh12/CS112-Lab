#include <iostream>
using namespace std;

#define pwrtwo(x) ((x & x-1)==0)

int main(int argc, char const *argv[])
{
	int num;
	cout<<"Enter a number to check"<<endl;
	cin>>num;
	int x=pwrtwo(num);

	if (x)
		cout<<"The entered number is in power of two."<<endl;
	else
		cout<<"The entered number is not in power of two."<<endl;
	return 0;
}
