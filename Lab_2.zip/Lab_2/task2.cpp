#include <iostream>
using namespace std;

#define pwrcal(num,x) (num << x)

int main(int argc, char const *argv[])
{
	int num1,num2;
	cout<<"Enter a first number"<<endl;
	cin>>num1;
	cout<<"Enter a second number"<<endl;
	cin>>num2;
	int x=pwrcal(num1,num2);
	
	cout<<"The answer is: "<<x<<endl;
	return 0;
}
