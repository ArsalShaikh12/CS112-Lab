
#include <iostream>

using namespace std;

class matrix {

	private:
		int size=3;
		int **A;
		int **B;

	public:
		void create() {
			A = new int *[size];
			for (int k=0;k<size;k++)
			{
				A[k]= new int [size];
			}
			B = new int *[size];
			for (int k=0;k<size;k++)
			{
				B[k]= new int [size];
			}
		}
		void initilize(){
			create();
			for (int i=0;i<size;i++)
			{
				for (int j=0;j<size;j++)
				{
					cin>>A[i][j];
				}
			}
		}
		void print();
		void transpose();
		bool isSymmetry();
		matrix multiply(matrix m1, matrix m2);

};

int main()
{
	matrix m1;
	int check;
	while(1)
	{
		cout<<endl<<"Please select an option\n"; 
		cout<<"1. Initialize an array" <<endl;
		cout<<"2. Transpose" <<endl;
		cout<<"3. Check for symmetry" <<endl;
		cout<<"4. Multiply" <<endl;
		cout<<"5. Display" <<endl;
		cout<<"6. Quit" <<endl;
		cin>>check;
		if (check == 1) {
			cout<<"Enter the values of first matrix"<<endl;
			m1.initilize();
		}
		else if (check == 2) {
			m1.transpose();
		}
		else if (check ==3 ) {
			if (m1.isSymmetry()){
				cout<<"The matrix is symmteric"<<endl;
			}
			else
			{
				cout<<"The matrix is not symmteric"<<endl;
			}
		}
		else if (check ==4 ) {
			matrix m2,m3;
			m3=m1.multiply(m1,m2);
			cout<<"returned"<<endl;
			m3.print();
		}
		else if (check ==5){
			m1.print();
		}
		else if (check ==6){
			break;
		}
		else {
			cout<<"Wrong input, please select again"<<endl;
			cout<<"1. Initialize an array" <<endl;
			cout<<"2. Transpose" <<endl;
			cout<<"3. Check for symmetry" <<endl;
			cout<<"4. Multiply" <<endl;
			cout<<"5. Display" <<endl;
			cout<<"6. Quit" <<endl;
		}
		} 

	return 0;
}

void matrix::print()
{
	for (int i=0;i<size;i++)
	{
		for (int j=0;j<size;j++)
		{
			cout<<A[i][j]<<"\t";	
		}
		cout<<endl;
	}
}

void matrix::transpose()
{
	cout<<"Without"<<endl;
	for (int i=0;i<size;i++)
	{
		for (int j=0;j<size;j++)
		{
			B[i][j]=A[j][i];
		}
	}
	cout<<"The transposed matrix is :\n"<<endl;
	for (int i=0;i<size;i++)
	{
		for (int j=0;j<size;j++)
		{
			cout<<B[i][j]<<"\t";
		}
		cout<<endl;
	}
}
bool matrix::isSymmetry()
{
	for (int i=0;i<size;i++)
	{
		for (int j=0;j<size;j++)
		{
			if (A[i][j]!=B[i][j])
			{
				return false;
			}
		}
	}
	return true;
}
matrix matrix::multiply(matrix m1, matrix m2)
{
	matrix m3;
	m3.create();
	cout<<"Enter the values of seconds array"<<endl;
	m2.initilize();
	for (int i=0;i<size;i++)
	{
		for (int j=0;j<size;j++)
		{
			for(int k = 0; k < size; ++k)
            {
                m3.A[i][j] += m1.A[i][k] * m2.A[k][j];
            }
		}
	}
	return m3;
	
}
