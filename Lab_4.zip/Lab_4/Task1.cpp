#include<iostream>

using namespace std;

class swapp
{
	int a,b;
public:
	void getdata();
	void swapv();
	void display();
};

void swapp::getdata()
{
	cout<<"Enter two numbers:";
	cin>>a>>b;
}

void swapp::swapv()
{
	a=a+b;
	b=a-b;
	a=a-b;
}

void swapp::display()
{
	cout<<"a="<<a<<"\tb="<<b<<endl;
}

int main()
{
	
	swapp s;
	
	s.getdata();
	cout<<"Before swap: \n";
	s.display();
	
	s.swapv();
	cout<<"After swap: \n";
	s.display();
	
	return 0;
}
